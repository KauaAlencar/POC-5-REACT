import Button from '../components/Button';

import Header from '../components/Header';


export default function Home() {
  return (
    
    <main>
      <Header />
      <p>Trabalho de Web Mobile POC 3</p>
      <Button />
    </main>


  );
}